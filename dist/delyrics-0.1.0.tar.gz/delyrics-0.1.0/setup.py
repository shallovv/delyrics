# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['delyrics']
install_requires = \
['mutagen>=1.45.1,<2.0.0']

setup_kwargs = {
    'name': 'delyrics',
    'version': '0.1.0',
    'description': 'Delete lyrics if mp3, mp4 and m4a',
    'long_description': '# delyrics\n\nDelete lyrics mp3, mp4 and m4a.\n\n## install \n\nhttp\n\n```Shell\n$ pip install git+https://github.com/shallovv/delyrics.git\n```\n\nssh\n\n```Shell\n$ pip install git+ssh://git@github.com:shallovv/delyrics.git\n```\n\n## Usage\n\n```Shell\n$ delyrics --help\nusage: delyrics.py [-h] [--mp3 MP3] [--mp4 MP4] [-f FOLDER]\n\nDelete lyrics of mp3, mp4 and m4a\n\noptional arguments:\n  -h, --help            show this help message and exit\n  --mp3 MP3             Delete lyrics of specified mp3\n  --mp4 MP4             Delete lyrics of specified mp4 or m4a\n  -f FOLDER, --folder FOLDER\n                        Delete lyrics of music in iTunes Media folder\n```',
    'author': 'shallovv',
    'author_email': 'miomio.ll.8507@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
