# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['delyrics']
install_requires = \
['mutagen>=1.45.1,<2.0.0']

entry_points = \
{'console_scripts': ['delyrics = delyrics:main']}

setup_kwargs = {
    'name': 'delyrics',
    'version': '0.1.2',
    'description': 'Delete lyrics of mp3, mp4 and m4a',
    'long_description': '# delyrics\n\nDelete lyrics of mp3, mp4 and m4a.\n\n## Install \n\nhttp\n\n```Shell\n$ pip install --user git+https://github.com/shallovv/delyrics.git\n```\n\nssh\n\n```Shell\n$ pip install --user git+ssh://git@github.com/shallovv/delyrics.git\n```\n\n## Uninstall\n\n```Shell\n$ pip uninstall delyrics\n```\n\n## Usage\n\n```Shell\n$ python3 -m delyrics --help\nusage: delyrics.py [-h] [--mp3 MP3] [--mp4 MP4] [-f FOLDER]\n\nDelete lyrics of mp3, mp4 and m4a\n\noptional arguments:\n  -h, --help            show this help message and exit\n  --mp3 MP3             Delete lyrics of specified mp3\n  --mp4 MP4             Delete lyrics of specified mp4 or m4a\n  -f FOLDER, --folder FOLDER\n                        Delete lyrics of music in iTunes Media folder\n```\n',
    'author': 'shallovv',
    'author_email': 'miomio.ll.8507@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
